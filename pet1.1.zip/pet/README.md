# pet

[![Package Version](https://img.shields.io/hexpm/v/pet)](https://hex.pm/packages/pet)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/pet/)

```sh
gleam add pet@1
```
```gleam
import pet

pub fn main() -> Nil {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/pet>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```
