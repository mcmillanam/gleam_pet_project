import * as pet from "./build/dev/javascript/pet/pet.mjs";

let currentPet = pet.new_pet("Fluffy");

function updateUI(message) {
  document.getElementById("pet-display").textContent = pet.show_pet(currentPet);
  if (message) {
    document.getElementById("log").textContent = message;
  }
}

// Initialize display
updateUI("Your pet has arrived!");

export function handleCommand(cmd) {
  switch (cmd.toLowerCase()) {
    case "feed": {
      const [newPet, msg] = pet.feed(currentPet);
      currentPet = newPet;
      updateUI(msg);
      break;
    }
    case "play": {
      const [newPet, msg] = pet.play(currentPet);
      currentPet = newPet;
      updateUI(msg);
      break;
    }
    case "sleep": {
      const [newPet, msg] = pet.sleep(currentPet);
      currentPet = newPet;
      updateUI(msg);
      break;
    }
    case "quit":
      alert("Goodbye! Thanks for playing.");
      break;
    default:
      alert("I don't understand that command.");
  }
}

window.handleCommand = handleCommand;
document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("feed-btn").addEventListener("click", () => handleCommand("feed"));
    document.getElementById("play-btn").addEventListener("click", () => handleCommand("play"));
    document.getElementById("sleep-btn").addEventListener("click", () => handleCommand("sleep"));
    document.getElementById("quit-btn").addEventListener("click", () => handleCommand("quit"));

})
