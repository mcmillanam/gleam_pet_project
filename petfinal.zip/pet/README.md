# pet

How to run:
Make sure gleam installed.
first install Homebrew:
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
then once homebrew is installed:
  brew update
  brew install gleam

cd into the project src folder.
run: python3 -m http.server 8000
go into browser enter http://localhost:8000/index.html

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```
