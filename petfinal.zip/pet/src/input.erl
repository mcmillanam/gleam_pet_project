-module(input).
-export([read_line/1]).

read_line(Prompt) ->
	io:get_line(Prompt).
